<?php

declare(strict_types=1);

namespace SB;


use pocketmine\block\Block;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\level\sound\GhastSound;
use pocketmine\network\mcpe\protocol\RemoveObjectivePacket;
use pocketmine\network\mcpe\protocol\SetDisplayObjectivePacket;
use pocketmine\network\mcpe\protocol\SetScorePacket;
use pocketmine\network\mcpe\protocol\types\ScorePacketEntry;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as f;
use DateTime;

class SB extends PluginBase implements Listener
{

    public function onEnable()
    {
        $this->getLogger()->info(f::GREEN . "Enabled!");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getScheduler()->scheduleRepeatingTask(new ScoreBoardTask($this), 20);
        $this->getLogger()->info("ScoreBoardTask gestartet!");
        }

    public function setScoreboardEntry(Player $player, int $score, string $msg, string $objName)
    {
        $entry = new ScorePacketEntry();
        $entry->objectiveName = $objName;
        $entry->type = 3;
        $entry->customName = " $msg   ";
        $entry->score = $score;
        $entry->scoreboardId = $score;
        $pk = new SetScorePacket();
        $pk->type = 0;
        $pk->entries[$score] = $entry;
        $player->sendDataPacket($pk);
    }

    public function rmScoreboardEntry(Player $player, int $score)
    {
        $pk = new SetScorePacket();
        if (isset($pk->entries[$score])) {
            unset($pk->entries[$score]);
            $player->sendDataPacket($pk);
        }
    }

    public function createScoreboard(Player $player, string $title, string $objName, string $slot = "sidebar", $order = 0)
    {
        $pk = new SetDisplayObjectivePacket();
        $pk->displaySlot = $slot;
        $pk->objectiveName = $objName;
        $pk->displayName = $title;
        $pk->criteriaName = "dummy";
        $pk->sortOrder = $order;
        $player->sendDataPacket($pk);
    }

    public function rmScoreboard(Player $player, string $objName)
    {
        $pk = new RemoveObjectivePacket();
        $pk->objectiveName = $objName;
        $player->sendDataPacket($pk);
    }

    public function onScore()
    {
        $pl = $this->getServer()->getOnlinePlayers();
        foreach ($pl as $player) {
            $name = $player->getName();
            $this->rmScoreboard($player, "objektName");
            $this->createScoreboard($player, "§l§eCityBuild", "objektName");
            $pfile = new Config("/root/Server/Coins/$name.yml", Config::YAML);
            $coins = $pfile->get("coins");
            $this->setScoreboardEntry($player, 1, " ", "objektName");
            $this->setScoreboardEntry($player, 2, f::WHITE . "» " . f::BOLD . f::RED . "Server ", "objektName");#»
            $this->setScoreboardEntry($player, 3, f::GRAY . "CityBuild-1", "objektName");
            $this->setScoreboardEntry($player, 4, "      ", "objektName");
            $this->setScoreboardEntry($player, 5, f::WHITE . "» " . f::BOLD . f::DARK_AQUA . "Online", "objektName");
            $this->setScoreboardEntry($player, 6, f::GRAY . count($this->getServer()->getOnlinePlayers()) . "/{$this->getServer()->getMaxPlayers()}", "objektName");
            $this->setScoreboardEntry($player, 7, " ", "objektName");
            $this->setScoreboardEntry($player, 8, f::WHITE . "» " . f::BOLD . f::GOLD . "Deine Coins", "objektName");
            $this->setScoreboardEntry($player, 9, f::GRAY . "$coins", "objektName");
        }
    }
    public function onDisable()
    {
          $this->getScheduler()->cancelAllTasks();
          $this->getLogger()->info(f::RED."Disabled!");
    }
}
