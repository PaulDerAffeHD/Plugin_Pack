<?php

namespace SB;

use pocketmine\scheduler\Task;

class ScoreBoardTask extends Task
{

    private $plugin;

    public function __construct(SB $plugin)
    {
          $this->plugin = $plugin;
    }

    public function onRun(int $currentTick)
    {
        $this->plugin->onScore();
     }
}
